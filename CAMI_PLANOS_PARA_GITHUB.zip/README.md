# Planos acotados — CAMI

Esta carpeta reúne los seis planos en PDF de las **tres cajas y sus tapas** del prototipo CAMI (Casco de Ayuda Minera Inmediata), modeladas en Autodesk Fusion 360. Las cotas indicadas en los dibujos están expresadas en **milímetros (mm)**.

## Archivos

| Módulo | Caja | Tapa |
|---|---|---|
| Control y sensor | [Plano de caja ESP32](01_Caja_Sensor_ESP32.pdf) | [Plano de tapa ESP32](02_Tapa_Sensor_ESP32.pdf) |
| Alimentación | [Plano de caja de batería](03_Caja_Bateria.pdf) | [Plano de tapa de batería](04_Tapa_Bateria.pdf) |
| Alertas | [Plano de caja de luces](05_Caja_Luces.pdf) | [Plano de tapa de luces](06_Tapa_Luces.pdf) |

## Propósito

Los planos documentan las vistas y las cotas obtenidas en Fusion 360 para identificar las dimensiones de las piezas, acompañar el diseño del encapsulado y apoyar su revisión y fabricación mediante impresión 3D.

Los **archivos editables `.f3d`** de las seis piezas se encuentran en la raíz del repositorio.

## Alcance de la documentación

Estos planos corresponden al estado de diseño registrado por el equipo. Algunos dibujos muestran dimensiones generales y cotas seleccionadas, por lo que **no deben considerarse planos de fabricación completamente acotados** sin revisar previamente espesores, tolerancias, posiciones de todas las aberturas y ajuste entre caja y tapa. No se han inventado cotas faltantes.

El módulo de control se relaciona con el rediseño del prototipo que utiliza un sensor MQ-7. Los planos documentan el encapsulado físico, no validan la calibración del sensor ni el funcionamiento eléctrico del sistema.
